<?php 

echo '
<link href="https://fonts.googleapis.com/css?family=Ubuntu:700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="views/css/style.css">
<link rel="icon" href="views/images/logo.png">
<title>Online Bazzar</title>
';

?>